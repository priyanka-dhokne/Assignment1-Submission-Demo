

const loginSection = document.getElementById('login-section');
const timerSection = document.getElementById('timer-section');
const breakTimerSection = document.getElementById('break-timer-section');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const loginButton = document.getElementById('login-button');
const timeDisplay = document.getElementById('time-display');
const breakTimeDisplay = document.getElementById('break-time-display');
const startButton = document.getElementById('start-button');
const resetButton = document.getElementById('reset-button');
const startBreakButton = document.getElementById('start-break-button');
const resetBreakButton = document.getElementById('reset-break-button');

let timer;
let isTimerRunning = false;
let isBreakTimerRunning = false;
let minutes = 25;
let breakMinutes = 5;
let seconds = 0;

loginButton.addEventListener('click', () => {
  const email = emailInput.value;
  const password = passwordInput.value;
  
  
  loginSection.style.display = 'none';
  timerSection.style.display = 'block';
});


